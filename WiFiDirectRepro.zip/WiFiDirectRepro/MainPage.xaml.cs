﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Enumeration;
using Windows.Devices.WiFiDirect;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Security.Cryptography;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Automation.Peers;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x804 上介绍了“空白页”项模板

namespace WiFiDirectRepro
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    
    public sealed partial class MainPage : Page
    {
        DeviceWatcher _deviceWatcher = null;
        bool _fWatcherStarted = false;
        WiFiDirectAdvertisementPublisher _publisher = new WiFiDirectAdvertisementPublisher();
        public ObservableCollection<DiscoveredDevice> DiscoveredDevices { get; } = new ObservableCollection<DiscoveredDevice>();
        public MainPage()
        {
            this.InitializeComponent(); 
            _publisher.StatusChanged += Status_Changed;
        }
        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            if (_deviceWatcher != null)
            {
                StopWatcher();
            }
        }
        private void StopWatcher()
        {
            _deviceWatcher.Added -= OnDeviceAdded;
            _deviceWatcher.Removed -= OnDeviceRemoved;
            _deviceWatcher.Updated -= OnDeviceUpdated;
            _deviceWatcher.EnumerationCompleted -= OnEnumerationCompleted;
            _deviceWatcher.Stopped -= OnStopped;

            _deviceWatcher.Stop();

            _deviceWatcher = null;
        }
        
        #region DeviceWatcherEvents
        private async void OnDeviceAdded(DeviceWatcher deviceWatcher, DeviceInformation deviceInfo)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                DiscoveredDevices.Add(new DiscoveredDevice(deviceInfo));
            });
        }

        private async void OnDeviceRemoved(DeviceWatcher deviceWatcher, DeviceInformationUpdate deviceInfoUpdate)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                foreach (DiscoveredDevice discoveredDevice in DiscoveredDevices)
                {
                    if (discoveredDevice.DeviceInfo.Id == deviceInfoUpdate.Id)
                    {
                        DiscoveredDevices.Remove(discoveredDevice);
                        break;
                    }
                }
            });
        }

        private async void OnDeviceUpdated(DeviceWatcher deviceWatcher, DeviceInformationUpdate deviceInfoUpdate)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                foreach (DiscoveredDevice discoveredDevice in DiscoveredDevices)
                {
                    if (discoveredDevice.DeviceInfo.Id == deviceInfoUpdate.Id)
                    {
                        discoveredDevice.UpdateDeviceInfo(deviceInfoUpdate);
                        break;
                    }
                }
            });
        }

        private void OnEnumerationCompleted(DeviceWatcher deviceWatcher, object o)
        {
            NotifyUserFromBackground("DeviceWatcher enumeration completed", NotifyType.StatusMessage);
        }

        private void OnStopped(DeviceWatcher deviceWatcher, object o)
        {
            NotifyUserFromBackground("DeviceWatcher stopped", NotifyType.StatusMessage);
        }
        #endregion

        public void NotifyUser(string strMessage, NotifyType type)
        {
            // If called from the UI thread, then update immediately.
            // Otherwise, schedule a task on the UI thread to perform the update.
            if (Dispatcher.HasThreadAccess)
            {
                UpdateStatus(strMessage, type);
            }
            else
            {
                var task = Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () => UpdateStatus(strMessage, type));
            }
        }

        private void UpdateStatus(string strMessage, NotifyType type)
        {
            switch (type)
            {
                case NotifyType.StatusMessage:
                    StatusBorder.Background = new SolidColorBrush(Windows.UI.Colors.Green);
                    break;
                case NotifyType.ErrorMessage:
                    StatusBorder.Background = new SolidColorBrush(Windows.UI.Colors.Red);
                    break;
            }

            StatusBlock.Text = strMessage;

            // Collapse the StatusBlock if it has no text to conserve real estate.
            StatusBorder.Visibility = (StatusBlock.Text != String.Empty) ? Visibility.Visible : Visibility.Collapsed;
            if (StatusBlock.Text != String.Empty)
            {
                StatusBorder.Visibility = Visibility.Visible;
                StatusPanel.Visibility = Visibility.Visible;
            }
            else
            {
                StatusBorder.Visibility = Visibility.Collapsed;
                StatusPanel.Visibility = Visibility.Collapsed;
            }

            // Raise an event if necessary to enable a screen reader to announce the status update.
            var peer = FrameworkElementAutomationPeer.FromElement(StatusBlock);
            if (peer != null)
            {
                peer.RaiseAutomationEvent(AutomationEvents.LiveRegionChanged);
            }
        }
        public async void NotifyUserFromBackground(string strMessage, NotifyType type)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                NotifyUser(strMessage, type);
            });
        }
        public enum NotifyType
        {
            StatusMessage,
            ErrorMessage
        };

        private void DiscoverButton_Click(object sender, RoutedEventArgs e)
        {
            if (_deviceWatcher == null)
            {
                DiscoveredDevices.Clear();
                NotifyUser("Finding Devices...", NotifyType.StatusMessage);

                String deviceSelector = WiFiDirectDevice.GetDeviceSelector(WiFiDirectDeviceSelectorType.AssociationEndpoint);

                _deviceWatcher = DeviceInformation.CreateWatcher(deviceSelector, new string[] { "System.Devices.WiFiDirect.InformationElements" });

                _deviceWatcher.Added += OnDeviceAdded;
                _deviceWatcher.Removed += OnDeviceRemoved;
                _deviceWatcher.Updated += OnDeviceUpdated;
                _deviceWatcher.EnumerationCompleted += OnEnumerationCompleted;
                _deviceWatcher.Stopped += OnStopped;

                _deviceWatcher.Start();

                DiscoverButton.Content = "Stop Watcher";
                _fWatcherStarted = true;
            }
            else
            {
                DiscoverButton.Content = "Start Watcher";

                StopWatcher();

                NotifyUser("Device watcher stopped.", NotifyType.StatusMessage);
            }
        }

        private void IEButton_Click(object sender, RoutedEventArgs e)
        {
            var discoveredDevice = (DiscoveredDevice)lvDiscoveredDevices.SelectedItem;
            try
            {
                _publisher.Stop();
            }
            catch (Exception)
            {

            }
            
            IList<WiFiDirectInformationElement> informationElements = null;
            try
            {
                informationElements = WiFiDirectInformationElement.CreateFromDeviceInformation(discoveredDevice.DeviceInfo);
            }
            catch (Exception ex)
            {
                NotifyUser("No Information element found: " + ex.Message, NotifyType.ErrorMessage);
            }

            if (informationElements != null)
            {
                StringWriter message = new StringWriter();

                foreach (WiFiDirectInformationElement informationElement in informationElements)
                {
                    string ouiName = CryptographicBuffer.EncodeToHexString(informationElement.Oui);
                    string value = string.Empty;
                    Byte[] bOui = informationElement.Oui.ToArray();

                    if (bOui.SequenceEqual(Globals.MsftOui))
                    {
                        
                        // The format of Microsoft information elements is documented here:
                        // https://msdn.microsoft.com/en-us/library/dn392651.aspx
                        // with errata here:
                        // https://msdn.microsoft.com/en-us/library/mt242386.aspx
                        ouiName += " (Microsoft)";
                        DataWriter dataWriter = new DataWriter();
                        byte[] ouiValue = { 0x10, 0x49,
                            0x00, 0x30,
                            0x00, 0x01, 0x37,

                             0x10, 0x0B,
                             0x00, 0x20,
                             0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19,
                             0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20,
                             0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09,
                             0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
                             0x10, 0x08,
                             0x00, 0x05,
                             0x53, 0x6D, 0x69, 0x74, 0x68};
                        dataWriter.UnicodeEncoding = UnicodeEncoding.Utf8;
                        dataWriter.ByteOrder = ByteOrder.LittleEndian;
                        dataWriter.WriteBytes(ouiValue);
                        informationElement.Value = dataWriter.DetachBuffer();
                        informationElement.Oui = CryptographicBuffer.CreateFromByteArray(Globals.MsftOui);
                        informationElement.OuiType = 0x04;
                        if(Convert.ToBoolean(AddIEButton.IsChecked))
                            _publisher.Advertisement.InformationElements.Add(informationElement);
                        _publisher.Start();
                    }
                    else if (bOui.SequenceEqual(Globals.WfaOui))
                    {
                        ouiName += " (WFA)";
                    }
                    else if (bOui.SequenceEqual(Globals.CustomOui))
                    {
                        ouiName += " (Custom)";

                        if (informationElement.OuiType == Globals.CustomOuiType)
                        {
                            DataReader dataReader = DataReader.FromBuffer(informationElement.Value);
                            dataReader.UnicodeEncoding = UnicodeEncoding.Utf8;
                            dataReader.ByteOrder = ByteOrder.LittleEndian;

                            // Read the string.
                            try
                            {
                                string data = dataReader.ReadString(dataReader.ReadUInt32());
                                value = $"Data: {data}";
                            }
                            catch (Exception)
                            {
                                value = "(Unable to parse)";
                            }
                        }
                    }

                    message.WriteLine($"OUI {ouiName}, Type {informationElement.OuiType} {value}");
                }

                message.Write($"Information elements found: {informationElements.Count}");

                NotifyUser(message.ToString(), NotifyType.StatusMessage);
            }
        }
        private void Status_Changed(WiFiDirectAdvertisementPublisher sender, WiFiDirectAdvertisementPublisherStatusChangedEventArgs args)
        {
            NotifyUser($"Publish Status Changed:{args.Status} - {args.Error}", NotifyType.StatusMessage);
        }

        private void AddIEButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
